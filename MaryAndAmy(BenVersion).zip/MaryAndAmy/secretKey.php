<?php
$SECRET="6LdoxUAUAAAAAPVSTseXLGvP9_g-7pDP5O4faHc_";
$SITE_KEY="6LdoxUAUAAAAALlVwvTOEnUfHkU5R1VtqQ4yHTny";
//before submitting this, create a new gmail and replace these keys, then hand over the gmail to the client
?>
