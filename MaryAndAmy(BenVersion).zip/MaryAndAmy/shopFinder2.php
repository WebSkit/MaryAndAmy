<?php
	require("googleMapsAPIKey.php");//go up a level, then find the file
require('databaseDetails.php');
 // Report all errors except E_NOTICE   
// error_reporting(E_ALL ^ E_NOTICE);  
	//require(realpath(dirname(__FILE__).'\..\googleMapsAPIKey.php'));
	//require(realpath(dirname(__FILE__).'\..\databaseDetails.php'));
	class shopFinder{
		var $apiKey;
		function __construct()
		{
			$this->apiKey=$GLOBALS["mapsAPIKey"];
		}//constructor
		function getConnection()
		{
			$connection=new mysqli($GLOBALS["server"],$GLOBALS["usernameS"],$GLOBALS["passwordS"],$GLOBALS["database"]);
			if($connection->connect_error)
			{
				die("Failed to establish a connection, please try again later");
			}//if there was a connection error
			return $connection;
		}
        
        
        
		function findValidShops($userPostCode)
		{
			$validCompaniesArray=array();
            
			$tempCount=0;//used to place items into the associative array without overwriting each other
			
            $query="SELECT * FROM baker";
			
            $connection=$this->getConnection();
			
            $result=$connection->query($query);
		
			while($row=$result->fetch_assoc())
			{
			
				$url="https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=".urlencode($userPostCode)."&destinations=".urlencode($row["postcode"])."&key=".urlencode($this->apiKey);
				
                
                $JSONDistance=file_get_contents($url);//the data is sent to this google page
				  //  echo '<pre>';  print_r($JSONDistance); echo '</pre>';
                
                $arrayDistance=json_decode($JSONDistance,true);//true=is associative array
				
                
            
              //  echo '<pre>';  print_r($arrayDistance); echo '</pre>';
                
				$distance=substr($arrayDistance["rows"][0]["elements"][0]["distance"]["text"],0,-3);
                
                
                
                //NOTE:gets the string, minus the last 3 characters(the space and the letters "mi"
				//"[row][0][elements][0][distance][text]"=the location of the distance(miles) in the array
				//distance between the customer and the baker
                //
                
				if($distance<=$row["servedArea"] and $userPostCode != null )
				{
					$query="SELECT AVG(rating) AS average FROM product INNER JOIN review ON product.productId WHERE bakerID=".$row["bakerID"];
					$resultReview=$connection->query($query);//finding the average review score
					$reviewAverage="No Reviews";//default value if a baker has no reviews
					//echo $resultReview->num_rows;
					
					$rowReview=$resultReview->fetch_assoc();
					
					//echo "the review score =".$rowReview["average"]."<br>";
					if($rowReview["average"]==null)
					{
						$reviewAverage="No Reviews";
					}
					else
					{
						$reviewAverage=$rowReview["average"];
					}
					$validCompaniesArray[$tempCount]=array("id"=>$row["bakerID"],"companyName"=>$row["companyName"],"addressLine1"=>$row["addressLine1"],"addressLine2"=>$row["addressLine2"],"postCode"=>$row["postcode"], "distance"=>$distance,"reviewScore"=>$reviewAverage);
					$tempCount=$tempCount+1;
				}//if the distance between the baker and customer is acceptable for both
				
               
			}//while there is an item in the returned results
			// echo '<pre>';  print_r($validCompaniesArray); echo '</pre>';
          
         
			return $validCompaniesArray;
            
		}//end findValidShops
        
        
        
	}//shopFinder class
//ratings, distance from the shopper's postcode, and the services done by the shop
?>