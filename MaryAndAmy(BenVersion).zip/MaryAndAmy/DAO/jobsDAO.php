<<?php
$requiredAddress=realpath(dirname(__FILE__).'\..\databaseDetails.php');
require($requiredAddress);
class jobsDAO{
    function __construct()
    {
    }//constructor
    function getConnection()
    {
        $connection=new mysqli($GLOBALS["server"],$GLOBALS["usernameS"],$GLOBALS["passwordS"],$GLOBALS["database"]);
        if($connection->connect_error)
        {
            die("Failed to establish a connection, please try again later");
        }//if there was a connection error
        return $connection;
    }//end getConnection

    function createJob() {

    }
 ?>
