<?php
	require(realpath(dirname(__FILE__).'\..\databaseDetails.php'));
	require(realpath(dirname(__FILE__).'\..\classes/enquiry.php'));
	
	class enquiryDAO
	{
		var $serverName;
		var $username;
		var $password;
		var $database;
		function __construct()
		{
			$this->serverName=$GLOBALS["server"];
			$this->username=$GLOBALS["usernameS"];
			$this->password=$GLOBALS["passwordS"];
			$this->database=$GLOBALS["database"];
		}//end constructor
		
		function getConnection()
		{
			$connection = new mysqli($this->serverName, $this->username, $this->password, $this->database);
			if($connection->connect_error)
			{
				die("Failed to establish a connection, please try again later");
			}//if there was a connection error
			return $connection;
		}//end getConnection
		
		function createEnquiry($newEnquiryObject)
		{
			$connection=$this->getConnection();
			$prepStatement=$connection->prepare("INSERT INTO enquiry (customerId, enquiryDescription, priceRange, dueBy) VALUES(?,?,?,?)");
			
			$customerId=$newEnquiryObject->getCustomerId();
			$enquiryDescription=$newEnquiryObject->getEnquiryDescription();
			$priceRange=$newEnquiryObject->getPriceRange();
			$dueBy=$newEnquiryObject->getDueBy();
			$prepStatement->bind_param("ssss",$customerId,$enquiryDescription,$priceRange,$dueBy);
			if($prepStatement->execute())
			{
				return true;
			}//if query was a success
			else
			{
				return false;
			}//if query was a failure
		}//end createEnquiry
		
	
		function getEnquiriesCust($customerID)
		{
			
			$connection=$this->getConnection();
            $query="SELECT *, DATE_FORMAT(dueBy,'%d-%m-%Y') AS dueByDate FROM enquiry WHERE customerID = ".$customerID;
			$result=$connection->query($query);
			$enquiriesArray=array();
			$tempCount=0;
            $currentDate = new DateTime();
			if($result->num_rows>0)
			{
				while($row=$result->fetch_assoc())
				{
					
                    $dueByDate = new DateTime($row['dueByDate']);
                    //if($dueByDate > $currentDate) {
    					$enquiriesArray[$tempCount]=array("enquiryID"=>$row["enquiryID"],"customerID"=>$row["customerID"],"enquiryDescription"=>$row["enquiryDescription"],"priceRange"=>$row["priceRange"],"dueBy"=>$row["dueByDate"]);
    					echo "<br>";
						$tempCount++;
                    //}
				}//while item in result object
				return $enquiriesArray;
			}//if there is data about enquiries
			else
			{
				return null;
			}//if no data, return null
		}//end getEnquiriesCust
		
		function findEnquiry($customerID)//used
		{
			$connection=$this->getConnection();
			$sql="SELECT MAX(enquiryID) from enquiry where customerID =".$customerID;//not a prep beacuse everything isnt decided by user
			
			//$prepStatement->bind_param("s",$customerId);
			if($result =$connection->query($sql))
			{
				return $result;
			}//if query was a success
			else
			{
				return false;
			}//if query was a failure
		}//end createEnquiry
	}
?>