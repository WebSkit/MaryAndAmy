<?php
	$requiredAddress=realpath(dirname(__FILE__).'/../databaseDetails.php');
	require($requiredAddress);
	if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
	class enquiriesDAO{
		function __construct()
		{
		}//constructor
		function getConnection()
		{
			$connection=new mysqli($GLOBALS["server"],$GLOBALS["usernameS"],$GLOBALS["passwordS"],$GLOBALS["database"]);
			if($connection->connect_error)
			{
				die("Failed to establish a connection, please try again later");
			}//if there was a connection error
			return $connection;
		}//end getConnection
		
		function rejectEnquiry($enquiryId,$enquireBakerId)
		{
				$enquiryId = str_replace(' ', '', $enquiryId);//remove spaces
			$enquiryId = preg_replace('/\s+/', '', $enquiryId);//remove whitespace

			$enquireBakerId = str_replace(' ', '', $enquireBakerId);
			$enquireBakerId = preg_replace('/\s+/', '', $enquireBakerId);
			
			
			
			$connection=$this->getConnection();
			$queryEnquiry="DELETE FROM enquiry WHERE enquiryID=?";
			$queryEnquireBaker="DELETE FROM enquirebaker WHERE enquireBakerID=?";
			
			$prepStatement=$connection->prepare($queryEnquireBaker);
			$prepStatement->bind_param("s",$enquireBakerId);
			
			if($prepStatement->execute())
			{
				$prepStatement2=$connection->prepare($queryEnquiry);
				$prepStatement2->bind_param("s",$enquiryId);
				if($prepStatement2->execute())
				{
					return true;
				}//if enquireBaker was removed
				else
				{
				
					return false;
				}//if query failed
			}//if the enquiry was removed
			else
			{
			
				return false;
			}//if query failed
		}//rejectEnquiry
		function acceptEnquiry($enquireBakerId)
		{
			$customerId;
			if(is_numeric($enquireBakerId))
			{
				$connection=$this->getConnection();
				$query="SELECT *,COUNT(*) as enquiryCount FROM enquirebaker WHERE bakerID=? AND enquireBakerID=?";
				$prepStatement=$connection->prepare($query);
				$prepStatement->bind_param("ss",$_SESSION["userId"],$enquireBakerId);

				if($prepStatement->execute())
				{
					$result=$prepStatement->get_result();
					$row=$result->fetch_assoc();

					if($row["enquiryCount"]>0)
					{

					}//if this enquiry does belong to this baker, allow the code to run
					else
					{
						return false;
					}//if the enquiry does not belong to the baker
				}
				else
				{
					return false;
				}//if query failed to execute


				$query="UPDATE enquirebaker SET bakerAccept=true WHERE enquireBakerID=?";
				$prepStatement=$connection->prepare($query);
				$prepStatement->bind_param("s",$enquireBakerId);
				if($prepStatement->execute())
				{
					$query="SELECT * FROM enquireBaker e JOIN enquiry en WHERE e.enquireBakerID=? AND e.enquiryID=en.enquiryID";
					$prepStatement=$connection->prepare($query);
					$prepStatement->bind_param("s",$enquireBakerId);

					if($prepStatement->execute())
					{
						$result=$prepStatement->get_result();
						$row=$result->fetch_assoc();
						$customerId=$row["customerID"];
						return $customerId;
					}//if the query executed successfully
					else
					{
						return false;
					}//if execution failed
				}//if the enquiry was approved
				else
				{
					return false;
				}//if accepting the enquiry failed
			}//if the id is a number
			else
			{
				return false;
			}//if the id isnt a number
		}//acceptEnquiry

		function linkConversation($conversationId,$enquireBakerID)
		{
			//echo $conversationId." and ".$enquireBakerID."<br>";
			//echo mysqli_connect_errno()."<br>";
			$connection=$this->getConnection();
			$query="UPDATE enquirebaker SET conversationId=? WHERE enquirebaker.enquireBakerID=?";
			//$query="SELECT * FROM enquirebaker WHERE enquireBakerID=?";
			$prepStatement=$connection->prepare($query);
			$prepStatement->bind_param("ss",$conversationId,$enquireBakerID);
//echo "statement executed";

			if($prepStatement->execute())
			{
								//echo $connection->error;
							//echo $prepStatement->error;
				$result=$prepStatement->get_result();
				return $conversationId;
			}//if the query successfully executed
			else
			{
				return false;
			}//if it failed to execute
		}//linkConversation
		
		function getEnquiries($bakerID)
		{
			//not using prepared statement as the bakerId is never chosen by the user, please tell me if there is anything I may have missed
			$connection=$this->getConnection();
			//query gets all fields from enquiry table as long as the bakerID in enquirebaker table is equal to the passed parameter
            //AND the enquiryID matches in both tables.
            $query="SELECT *, DATE_FORMAT(dueBy,'%d-%m-%Y') AS dueByDate FROM enquiry AS e JOIN enquirebaker AS eb WHERE eb.bakerID=".$bakerID." AND e.enquiryID=eb.enquiryID ORDER BY dueBy";
			if($result=$connection->query($query))
			{
				//echo "successful query";
			}
			else
			{
				echo $connection->error;
			}
			$enquiriesArray=array();
			$tempCount=0;
            $currentDate = new DateTime();
			if($result->num_rows>0)
			{
				while($row=$result->fetch_assoc())
				{
					//echo "<br>";
                    $dueByDate = new DateTime($row['dueByDate']);
                    if($dueByDate > $currentDate) {

                        //possible to add enquiryid: ->>> "enquiryID"=>$row["enquiryID"],
    					$enquiriesArray[$tempCount]=array("customerID"=>$row["customerID"],"enquiryDescription"=>$row["enquiryDescription"],"priceRange"=>$row["priceRange"],"dueBy"=>$row["dueByDate"],"bakerId"=>$row["bakerID"],"enquireBakerID"=>$row["enquireBakerID"], "enquiryID"=>$row["enquiryID"],"bakerAccept"=>$row["bakerAccept"], "conversationId"=>$row["conversationId"]);
    					$tempCount++;
                    }
				}//while item in result object
				return $enquiriesArray;
			}//if there is data about enquiries
			else
			{
				return null;
			}//if no data, return null
		}//end getEnquiries


	
	//Jeffs stuff below
function createEnquiry($newEnquiryObject)
		{
			$connection=$this->getConnection();
			$prepStatement=$connection->prepare("INSERT INTO enquiry (customerId, enquiryDescription, priceRange, dueBy) VALUES(?,?,?,?)");
			
			$customerId=$newEnquiryObject->getCustomerId();
			$enquiryDescription=$newEnquiryObject->getEnquiryDescription();
			$priceRange=$newEnquiryObject->getPriceRange();
			$dueBy=$newEnquiryObject->getDueBy();
			$prepStatement->bind_param("ssss",$customerId,$enquiryDescription,$priceRange,$dueBy);
			if($prepStatement->execute())
			{
				return true;
			}//if query was a success
			else
			{
				return false;
			}//if query was a failure
		}//end createEnquiry
		
	
		function getEnquiriesCust($customerID)
		{
			
			$connection=$this->getConnection();
            //$query="SELECT *, DATE_FORMAT(dueBy,'%d-%m-%Y') AS dueByDate FROM enquiry AS en JOIN enquirebaker eb WHERE customerID = ".$customerID;
			$query="SELECT *, DATE_FORMAT(dueBy,'%d-%m-%Y')  AS dueByDate FROM enquiry AS en JOIN enquirebaker AS eb WHERE en.customerID = ".$customerID." AND eb.enquiryID=en.enquiryID";

			/*if($result=$connection->query($query))
			{
				echo "successful query";
			}
			else
			{
				echo $connection->error;
			}*/
			$result=$connection->query($query);
			$enquiriesArray=array();
			$tempCount=0;
            $currentDate = new DateTime();
			if($result->num_rows>0)
			{
				while($row=$result->fetch_assoc())
				{
					
                    $dueByDate = new DateTime($row['dueByDate']);
                    //if($dueByDate > $currentDate) {
    					$enquiriesArray[$tempCount]=array("enquiryID"=>$row["enquiryID"],"customerID"=>$row["customerID"],"enquiryDescription"=>$row["enquiryDescription"],"priceRange"=>$row["priceRange"],"dueBy"=>$row["dueByDate"],"enquireBakerID"=>$row["enquireBakerID"],"conversationId"=>$row["conversationId"],"bakerAccept"=>$row["bakerAccept"]);
    					echo "<br>";
						$tempCount++;
                    //}
				}//while item in result object
				return $enquiriesArray;
			}//if there is data about enquiries
			else
			{
				return null;
			}//if no data, return null
		}//end getEnquiriesCust
	}//end enquiriesDAO class


?>

