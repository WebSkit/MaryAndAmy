<?php
	require(realpath(dirname(__FILE__).'\..\databaseDetails.php'));
	require(realpath(dirname(__FILE__).'\..\classes/enquireBaker.php'));

	class enquireBakerDAO
	{
		var $serverName;
		var $username;
		var $password;
		var $database;
		function __construct()
		{
			$this->serverName=$GLOBALS["server"];
			$this->username=$GLOBALS["usernameS"];
			$this->password=$GLOBALS["passwordS"];
			$this->database=$GLOBALS["database"];
		}//end constructor
		
		function getConnection()
		{
			$connection = new mysqli($this->serverName, $this->username, $this->password, $this->database);
			if($connection->connect_error)
			{
				die("Failed to establish a connection, please try again later");
			}//if there was a connection error
			return $connection;
		}//end getConnection
		
		function createEnquireBaker($newEnquireBakerObject)//used
		{
			$connection=$this->getConnection();
			$prepStatement=$connection->prepare("INSERT INTO enquirebaker (enquireBakerID, bakerID, enquiryID, customerAccept, bakerAccept) VALUES(NULL,?,?,?,?)");
			$bakerId=$newEnquireBakerObject->getBakerId();
			$enquiryID=$newEnquireBakerObject->getEnquiryID();
			$customerAccept=$newEnquireBakerObject->getCustomerAccept();
			$bakerAccept=$newEnquireBakerObject->getBakerAccept();
			$prepStatement->bind_param("ssss",$bakerId,$enquiryID,$customerAccept,$bakerAccept);
			if($prepStatement->execute())
			{
				return true;
			}//if query was a success
			else
			{
				return false;
			}//if query was a failure
		}//end createEnquiry
	}//end of class
?>