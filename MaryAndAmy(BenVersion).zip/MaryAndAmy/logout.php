<?php
session_start();
unset($_SESSION["userId"]);
unset($_SESSION["accountType"]);
session_unset();
session_destroy();

header("location:login2.php");


?>