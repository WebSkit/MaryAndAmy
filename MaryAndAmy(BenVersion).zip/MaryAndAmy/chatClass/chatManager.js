//1. ADD CODE TO REMOVE ANY "<" OR ">" FROM BEING PLACED IN THE CODE(TO PREVENT JAVASCRIPT INJECTION)(completed)
//2.CONVERT THIS TO MAKE IT COMPATIBLE WITH FACEBOOK STYLED CHATS(AKA MAKE GREATER USE OF CLASSES)(DONE)
//3.when you have made the cht facebook-styled(rather than the current chat room styled) implement a second refresh so that it goes through all the open conversations and refreshes there messages
//(DONE task 3)
document.addEventListener("DOMContentLoaded", initialisePage);
window.setInterval(refreshAllChats,2000);
function initialisePage()
{
	
	//create "removeEventListener" versions of all of these(for whenever the enquiries table is refreshed(but the table isnt loaded)
	
	var sendMessageButton=document.getElementsByClassName("sendMessage");
	for (var i = 0; i < sendMessageButton.length; i++) {
		sendMessageButton[i].addEventListener('click', sendMessage);
	}//for each item in the sendMessageButton list#
	var createConvButton=document.getElementsByClassName("createConv");
	for(var i=0;i<createConvButton.length;i++)
	{
		createConvButton[i].addEventListener("click",enquiryUpdater);
	}
	var rejectEnquiryButtons=document.getElementsByClassName("rejectEnquiry");
	for(var i=0;i<rejectEnquiryButtons.length;i++)
	{
		rejectEnquiryButtons[i].addEventListener("click",rejectEnquiry);
	}
	
	var openChatButtons=document.getElementsByClassName("openChat")
	for(var i=0;i<openChatButtons.length;i++)
	{
		openChatButtons[i].addEventListener("click",createChatAreaConduit);
	}
	
	
}

function rejectEnquiry()
{
	var rejectButton=this;
	var enquireBakerId=rejectButton.dataset.enquirebakerid
	var enquiryId=rejectButton.dataset.enquiryid;
	
	xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(this.responseText=="false")
			{
				alert("request failed");
			}
			else
			{
				//alert("success");
				location.reload();//if time, change this so that ajax reloads only the enquiries section
				//this reloads the page
			}
			//return customerId;
		}//if the request completed and was successful
	};//onreadystatechange
		//var message=messageTextBox.value;
		xmlhttp.open("POST", "../bakerOptions/rejectEnquiry.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send("enquireBakerId="+enquireBakerId+"&enquiryId="+enquiryId);
}

function enquiryUpdater()
{
	var acceptButton=this;
	var enquiryId=acceptButton.dataset.enquiryid;
	var enquireBakerId=acceptButton.dataset.enquirebakerid;
	//alert("enquiryUpdater called "+enquiryId+" "+enquireBakerId);
	var customerId=acceptEnquiry(enquireBakerId);//returns the customerId
	//alert("is there a customerId?, customerId= "+customerId);
	
	//var conversationId=createConversation();//returns the new conversationId
	//createChat();//creates the chat box on screen
}

function acceptEnquiry(enquireBakerId)
{
	xmlhttp=new XMLHttpRequest();
	var customerId;
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(this.responseText=="false")
			{
				alert("requested failed");
			}
			else
			{
				customerId=this.responseText;
				//alert("request accepted "+customerId);
				//alert("acceptEnquiry success, customerId= "+customerId+" and enquireBakerId= "+enquireBakerId);
				createConversation(customerId,enquireBakerId);
				
			}
			//return customerId;
		}//if the request completed and was successful
	};//onreadystatechange
		//var message=messageTextBox.value;
		xmlhttp.open("POST", "../bakerOptions/acceptEnquiry.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send("enquireBakerId="+enquireBakerId);
}//end acceptEnquiry

function createConversation(customerId,enquireBakerId)
{
	//alert(customerId);
	xmlhttp=new XMLHttpRequest();
	var conversatonId;
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(this.responseText=="false")
			{
				alert("requested failed");
			}
			else
			{
				conversationId=this.responseText;
				//alert("request accepted(createConv)");
				//alert("createConversation success, conversationId= "+conversationId);
				conversationId=conversationId.trim();
				createChatArea(conversationId);
			}
			//return customerId;
		}//if the request completed and was successful
	};//onreadystatechange
		//var message=messageTextBox.value;
		xmlhttp.open("POST", "../chatClass/createConversation.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send("customerId="+customerId+"&enquireBakerId="+enquireBakerId);
}//createConversation

function createChatArea(conversationId)
{
	xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(this.responseText=="false")
			{
				alert("requested failed");
			}
			else
			{
				var newChat=this.responseText;
				//alert("request accepted(createChatArea)");
				var chatCollection=document.getElementById("chatCollection");
				chatCollection.innerHTML+=newChat;
				resetRefreshListeners();
				refreshEnquiriesTable();//THIS IS UNDERFINED. SO DO THIS TOMORROW ON SUNDAY
				//this method will reload the entire enquiries table(so that a "chat" button may appear
				
			}
			//return customerId;
		}//if the request completed and was successful
	};//onreadystatechange
		//var message=messageTextBox.value;
		xmlhttp.open("POST", "../chatClass/generateChatBox.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send("conversationId="+conversationId);
}//createChatArea
function refreshEnquiriesTable()
{
	var enquiriesArea=document.getElementById("enquiriesList");
	
	xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(this.responseText=="false")
			{
				alert("requested failed");
			}
			else
			{
				enquiriesArea.innerHTML=this.responseText;
				initialisePage();//refresh all the event listeners(THIS NEEDS SOME MORE EDITTING, LOOK AT THE initialisePage FUNCTION FOR MORE DETAILS)
				
			}
			//return customerId;
		}//if the request completed and was successful
	};//onreadystatechange
		//var message=messageTextBox.value;
		xmlhttp.open("POST", "getEnquireiesTable.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send();
	
}//refresh the enquiries table
function createChatAreaConduit()
{
	var button=this;
	createChatArea(button.dataset.conversationid);
}

function resetRefreshListeners()
{
	var sendMessageButton=document.getElementsByClassName("sendMessage");
	for (var i = 0; i < sendMessageButton.length; i++) {
		sendMessageButton[i].removeEventListener('click', sendMessage);
	}//for each item in the sendMessageButton list#
	
	var sendMessageButton=document.getElementsByClassName("sendMessage");
	for (var i = 0; i < sendMessageButton.length; i++) {
		sendMessageButton[i].addEventListener('click', sendMessage);
	}//for each item in the sendMessageButton list#
	
	var closeChatButtons=document.getElementsByClassName("closeChat");
	for (var i = 0; i < closeChatButtons.length; i++) {
		closeChatButtons[i].removeEventListener('click', removeChatBox);
	}//for each item in the closeChatButtons list#
	
	
	var closeChatButtons=document.getElementsByClassName("closeChat");
	for (var i = 0; i < closeChatButtons.length; i++) {
		closeChatButtons[i].addEventListener('click', removeChatBox);
	}//for each item in the closeChatButtons list#
	
	
}//resetRefreshListeners(resets all the send message event listeners to account for new buttons

function removeChatBox()
{
	var button=this;//button that initiated removal
	
	var chatCollection=document.getElementById("chatCollection");
	var conversationId=button.dataset.conversationid;
	
	var chatContainerList=document.getElementsByClassName("chatContainer");
	
	for (var i = 0; i < chatContainerList.length; i++) {
		if(conversationId==chatContainerList[i].dataset.conversationid)
		{
			chatCollection.removeChild(chatContainerList[i]);
			break;
		}
		
	}//for each item in the chatContainerList list#
	
	resetRefreshListeners();
}//removeChatBox
function sendMessage()
{
	var messageButton=this;//used to access the conversation id
	
	var messageTextBoxList=document.getElementsByClassName("message");
	var messageTextBox;

	for (var i = 0; i < messageTextBoxList.length; i++) {
		
		if(messageTextBoxList[i].dataset.conversationid==messageButton.dataset.conversationid)
		{
			messageTextBox=messageTextBoxList[i];
			break;
		}//if the message has the same conversationId as the 
	}//for each item in the messageTextBoxList list
	var conversationId=messageButton.dataset.conversationid;

	xmlhttp=new XMLHttpRequest();
	
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(this.responseText==false)
			{
				alert("something went wrong");
			}
			else
			{
				refreshChat(conversationId);
			}
		}//if the request completed and was successful
	};//onreadystatechange
		var message=messageTextBox.value;
		message = message.replace(/</g, "&lt;").replace(/>/g, "&gt;");//for all instances(g) of < and >, replace with the safe versions(stops javascript injection)
		xmlhttp.open("POST", "../chatClass/sendMessage.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send("conversationId="+conversationId+"&message="+message);

	
}
function refreshChat(conversationId)
{
	var chatAreaList=document.getElementsByClassName("chatArea");
	var chatArea;

	
	for (var i = 0; i < chatAreaList.length; i++) {
		
		if(chatAreaList[i].dataset.conversationid==conversationId)
		{
			chatArea=chatAreaList[i];
			break;
		}//if the chatArea has the same conversationId as the parameter
	}//for each item in the chatAreaList
	
	xmlhttp=new XMLHttpRequest();
	
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(this.responseText==false)
			{
			}
			else
			{
				console.log("response successful");
				var messageArea=chatArea;
				messageArea.innerHTML=this.responseText;
			}
		}//if the request completed and was successful
	};//onreadystatechange
		xmlhttp.open("POST", "../chatClass/refreshMessages.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send("conversationId="+conversationId);
}//end refreshMessage

function refreshAllChats()
{
	console.log("refreshAllChats entered");
	var chatAreaList=document.getElementsByClassName("chatArea");
	var activeChatArea;

	for (var i = 0; i < chatAreaList.length; i++) {
		
		activeChatArea=chatAreaList[i];
		var conversationId=activeChatArea.dataset.conversationid;
		refreshSingle(activeChatArea,conversationId);//makes the ajax request and modifies the html
	}//for each item in the chatAreaList

}//end refreshAllChats

function refreshSingle(areaToEdit,conversationId)
{
	xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(this.responseText==false)
			{

			}
			else
			{
				
				var messageArea=areaToEdit;
				messageArea.innerHTML=this.responseText;
				messageArea.innerHTML;

			}
		}//if the request completed and was successful
	};//onreadystatechange
		xmlhttp.open("POST", "../chatClass/refreshMessages.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send("conversationId="+conversationId);
}//performs ajax request for the refreshAllChat method

