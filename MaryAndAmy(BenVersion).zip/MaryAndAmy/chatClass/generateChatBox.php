<?php
require("chat.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if($_SESSION["accountType"]=="baker")
{
	require("../userDAOClasses/customerDAO.php");
}//if baker, allow messaging of customers
else
{
	require("../userDAOClasses/bakerDAO.php");
}//if customer, allow messaging of baker
$conversationId=$_POST["conversationId"];
//$conversationId=1;
//$_SESSION["userId"]=1;
//$_SESSION["accountType"]="baker";



$chatDAO=new chatDAO();
$bakerOwnsConv=$chatDAO->convBelongsToBaker($_SESSION["userId"],$conversationId);

if($bakerOwnsConv==true)
{
	$recieaverId=$chatDAO->getRecieverId($_SESSION["userId"],$_SESSION["accountType"],$conversationId);//get the id of person that the current user will talk to
	$object;
	$name;
	if($_SESSION["accountType"]=="baker")
	{
		$customerDAO=new customerDAO();
		$object=$customerDAO->getCustomerObject($recieaverId);//get customer object
		$name=$object->getName();
	}
	else
	{
		$bakerDAO=new bakerDAO();
		$object=$bakerDAO->getBakerObject($recieaverId);//get baker object
		$name=$object->getContactName()."(".$object->getName().")";
	}
	$chatResults=$chatDAO->refreshMessageBoard($conversationId,$_SESSION["userId"],$_SESSION["accountType"]);//get all messages between the two users

	?>
	
	
	
	
	
	
	<?php $htmlOutput="<div max-height:70px; max-width:20%;'  class='chatContainer' data-conversationid='".$conversationId."'>";?>
	<?php $htmlOutput.="<p>Chat Partner : ".$name."</p>";?>
	<?php $htmlOutput.="<div style='max-width:20%; max-height:70px; overflow:scroll;' class='chatArea' data-conversationid='".$conversationId."'>"; ?>
		<?php
		if($chatResults==false)
		{
			$htmlOutput.="<h1>Something went wrong with the chat, please try again later</h1>";
			
		}//if the chat query failed
		else
		{
			$chatSize=sizeOf($chatResults);
			
			for($i=0;$i<$chatSize;$i++)
			{
				if($chatResults[$i]["chatType"]=="CTB")
				{
					$htmlOutput.="<div class=customerMessage>".$chatResults[$i]["firstName"]." ".$chatResults[$i]["surname"]." : ".$chatResults[$i]["message"]."</div><br>";
				}//if customer sent message
				elseif($chatResults[$i]["chatType"]=="BTC")
				{
					$htmlOutput.="<div class=bakerMessage>".$chatResults[$i]["contactName"]."(".$chatResults[$i]["companyName"].") : ".$chatResults[$i]["message"]."</div><br>";

				}//if baker sent message
				else
				{
					$htmlOutput.="something went wrong with chat, please try again later";
				}//if there is some error
			}//for each chat messaeg in array
		}//if the query was successful
		?>
		<?php $htmlOutput.="</div><!--end chatArea-->"?>
		<?php $htmlOutput.="<input type='text' class='message' data-conversationId='".$conversationId."'></input>" ;?>
		<?php $htmlOutput.="<input type='button' class='sendMessage' data-conversationId='".$conversationId."' value='Send Message'></input>";?>
		<?php $htmlOutput.="<input type='button' class='closeChat' data-conversationId='".$conversationId."' value='Close Chat'></input>";?>
		<?php $htmlOutput.="</div><!--end chatContainer-->";?>
	
	
	<?php echo $htmlOutput?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
<?php
	
	
}//if the baker does own the conversation
else
{
	echo "false";
}//if the baker does not own the conversation


?>