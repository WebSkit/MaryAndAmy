<?php
	include("../userDAOClasses/customerDAO.php");
	if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
	//for deleting a customer
	if(isset($_POST["CDSubmit"]))
	{
		$tempDAO=new CustomerDAO();
		$accountDeleted=$tempDAO->deleteCustomer($_POST["customerId"]);
		if($accountDeleted==true)
		{
			echo "customer account is deleted";
		}
		else
		{
			echo "something went wrong, please try again later";
		}	
	}//if data was submitted successfully from the form
	?>
<!DOCTYPE HTML>
<head>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Delete Customer</title>
	<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
</head>
<body>
<header>


      <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>
 
 
        </div>
 
 
        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="../login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="../images/logins.png">
 
          </ul>
        </nav>
      </div>
 
 
 
    </header>
 
    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>
	<h2>Delete a Customer</h2>
	<form method="post" id="deleteCustomerForm">
		<h3>Comstumer ID</h3>
		<input type="text" name="customerId">
		<input type="submit" value="Delete Customer" name="CDSubmit">
	</form><!--end deleteCustomerForm-->
	<footer>
		<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
	</footer>
	</body>