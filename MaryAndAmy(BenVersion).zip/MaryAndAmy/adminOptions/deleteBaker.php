<?php
	include("../userDAOClasses/bakerDAO.php");
	if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
	//$_SESSION["userId"]=1;
	//$_SESSION["accountType"]="admin";
	
	//for deleting a baker
	if(isset($_POST["BDSubmit"]))
	{
		$tempDAO=new bakerDAO();
		$accountDeleted=$tempDAO->deleteBaker($_POST["bakerId"]);
		if($accountDeleted==true)
		{
			echo "baker account is deleted";
		}
		else
		{
			echo "something went wrong, please try again later";
		}	
	}//if data was submitted successfully from the form
	
?>
<!DOCTYPE HTML>
<head>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Remove a Baker</title>
	<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
</head>
	<body>
	<header>


      <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>
 
 
        </div>
 
 
        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="../login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="../images/logins.png">
 
          </ul>
        </nav>
      </div>
 
 
 
    </header>
 
    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>
	<h2>Delete a Baker</h2>
	<form method="post" id="deleteBakerForm">
		<h3>Baker ID</h3>
		<input type="text" name="bakerId">
		<input type="submit" value="Delete Baker" name="BDSubmit">
	</form><!--end deleteBakerForm-->
	<footer>
		<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
	</footer>
	</body>
</html>