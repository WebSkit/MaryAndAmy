<?php
	//session_start();
	include('../userDAOClasses/customerDAO.php');
	include('../DAO/enquiriesDAO.php');
	if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
	//$_SESSION["userId"]=1;
	//$_SESSION["accountType"]="customer";
	?>
	<head>
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<title>Create Baker Account</title>
		<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
	</head>
	<body>
	<script type="text/javascript" src="../chatClass/chatManager.js"></script>

	<header>


      <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>
 
 
        </div>
 
 
        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="../login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="images/logins.png">
 
          </ul>
        </nav>
      </div>
 
 
 
    </header>
 
    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>
	
	<a href="updatecustomer.php"><button type="button" name="editAccountDetails" value="Edit Account Details">Change your details</button></a>
	<a href="createEnquiries.php"><button type="button" name="addEnquiry" value="Add enquiry">Make an enquiry</button></a>
	
	<h2>Current Enquiries</h2>
	<form method="post" id="seeBakers">
<?php
		$tempDAO=new enquiriesDAO();
		$enquiryArray=$tempDAO->getEnquiriesCust($_SESSION["userId"]);
		if($enquiryArray!=null)
		{				
			$enquiryCount=sizeof($enquiryArray);
			$tempCount=0;
			while($tempCount<$enquiryCount)
			{
				$d=$enquiryArray[$tempCount]["dueBy"]
?>		
				<ul id="enquiry "<?php echo $tempCount+1;?>>
					<li>Enquiry Description: <?php echo $enquiryArray[$tempCount]["enquiryDescription"];?></li>
					<ul>Price Range: <?php echo $enquiryArray[$tempCount]["priceRange"];?></ul>
					<!--not working yet-->
					<ul>Due By Date: <?php echo $d;?></ul>
					<?php if($enquiryArray[$tempCount]["bakerAccept"]==true){?>
					<ul><button data-enquirebakerid="<?php echo $enquiryArray[$tempCount]["enquireBakerID"]; ?>" data-enquiryid="<?php echo $enquiryArray[$tempCount]["enquiryID"]; ?>" data-conversationid="<?php echo $enquiryArray[$tempCount]["conversationId"]; ?>" style="width:20%"type="button" class="openChat" name="chatButton">Chat</button></ul>
					<?php }//if the baker accepted the enquiry, allow the chat?>
				</ul>	
<?php
				$tempCount++;
			}//while there are reviews in the list
		}else
		{
			echo "something went wrong, please try again later";
		}	
?>
	</form>
	<section id="chatCollection">
					
				</section><!--end chatCollection-->
	<footer>
		<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
	</footer>
	
</body>

