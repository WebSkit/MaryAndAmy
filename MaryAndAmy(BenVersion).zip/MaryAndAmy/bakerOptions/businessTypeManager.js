document.addEventListener("DOMContentLoaded", initialisePage);

function initialisePage()
{
	var removeBusinessTypeButtons=document.getElementsByClassName("removeService");
	
	for(var i=0;i<removeBusinessTypeButtons.length;i++)
	{
		removeBusinessTypeButtons[i].addEventListener("click",removeBusinessType);
	}//for each removeService button
}//end initialisePage

function removeBusinessType()
{
	
	var removeButton=this;
	var businesstypeid=removeButton.dataset.businesstypeid;
	xmlhttp=new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(this.responseText=="false")
			{
				alert("request failed");
			}
			else
			{
				location.reload();
				//this reloads the page
			}
			//return customerId;
		}//if the request completed and was successful
	};//onreadystatechange
		xmlhttp.open("POST", "removeBusinessType.php", true);
		xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xmlhttp.send("businessTypeId="+businesstypeid);
}