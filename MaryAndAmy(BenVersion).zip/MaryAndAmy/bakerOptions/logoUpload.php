<?php
//session_start();
//session is started in the bakerDAO class so not needed here
require("../userDAOClasses/bakerDAO.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$target_dir = "../logos/"."BakerId".$_SESSION["userId"];
if(!file_exists($target_dir) && !is_dir($target_dir))
{
	mkdir($target_dir,0666);//code 666=everyone can read or write to the file
}//if the folder does not exist as a file or directory

$target_file = $target_dir ."/". basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image


if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// file existing check
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}//if the file exists already as the logo
else
{
	
$files = scandir ($target_dir); // returns an array of all files in a given directory
$arraySize=sizeof($files);
for($i=0;$i<$arraySize;$i++){ // iterate through files in folder
 
 
 if($files[$i]=="." || $files[$i]=="..")
 {
 }//if the system finds the two dot values that linux systems add to the list
 else
 {
	 if(unlink($target_dir."/".$files[$i])) // delete file
	{
		echo "success";
	}
	else
	{
		echo "failure";
	}
 }//else
   
  
}//for each item in array
}//if the file does not exist as a logo already
	//mkdir($target_dir);//aka delete the old logo

// file size check 
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// only JPG, PNG & GIF formats
if($imageFileType != "jpg" && $imageFileType != "JPG" && $imageFileType != "png" && $imageFileType != "PNG" && $imageFileType != "JPEG" && $imageFileType != "jpeg"
&& $imageFileType != "GIF" && $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
	
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
		echo $target_file;
		
		$bakerDAO=new bakerDAO();
		$dataUpdated=$bakerDAO->setLogo($_SESSION["userId"],$target_file);
		chmod($target_file,0666);

		if($dataUpdated==true)
		{
			echo "<br>The database was updated";
		}
		else
		{
			echo "<br>The database was not updated";
		}
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>

