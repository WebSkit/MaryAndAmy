<?php
require("../userDAOClasses/businessTypeClass.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
//$_SESSION["userId"]=1;
//$_SESSION["accountType"]="baker";
$businessDAO=new businessTypeDAO();
$businessTypeData=$businessDAO->getAllBusinessTypes();
if(isset($_POST["businessTypeSubmit"]))
{
	$businessTypeAdded=$businessDAO->addBusinessType($_POST["businessTypeId"],$_SESSION["userId"]);
	
	
}//goes first so that the data is updated on reload
$activeBusinessType=$businessDAO->getAllActiveBusinessTypes($_SESSION["userId"]);




?>
<!DOCTYPE html>
	<head>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Add Services</title>
	<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
</head>
	
	
	<body>
		<script type="text/javascript" src="businessTypeManager.js"></script>

		<header>


      <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>
 
 
        </div>
 
 
        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="../login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="../images/logins.png">
 
          </ul>
        </nav>
      </div>
 
 
 
    </header>
 
    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>
	
		<article id="businessTypes">
		
		<?php 
			if($activeBusinessType==false)
			{
				echo "<h1>You have no service types, please select one from the adjacent list</h1>";
			}
			else
			{
				?>
			<ul id="businessTypesList">
				<?php
					$arraySize=sizeof($activeBusinessType);
					
					for($i=0;$i<$arraySize;$i++)
					{
					echo "<li data-businesstypeid=".$activeBusinessType[$i]["businessTypeId"].">".$activeBusinessType[$i]["businessType"]."   <button class='removeService' data-businesstypeid=".$activeBusinessType[$i]["businessTypeId"]." value='Remove'>Remove</button></li><br>"; 
					}
				?>
			</ul>
			
			<?php 
			}//if the array has businessType data in it
			?>
		</article>
		
		<article>
			
			<select id="BusinessTypesSelect" form="addBusinessType" name='businessTypeId'>
				<?php if($businessTypeData!=false)
				{	
					$listSize=sizeof($businessTypeData);
					for($i=0;$i<$listSize;$i++)
					{
						echo "<option  value='".$businessTypeData[$i]["businessTypeId"]."'>".$businessTypeData[$i]["businessType"]."</option>";
					}//for each businessType in the list
				}//if the data does exist
				
				?>
			</select>
			<form id="addBusinessType" method="POST" >
				<input type="submit" name="businessTypeSubmit"></input>
			</form>
			<?php if(isset($_POST["businessTypeSubmit"]) && $businessTypeAdded==true){echo "<p>Your new service has been added</p>";}if(isset($_POST["businessTypeSubmit"]) && $businessTypeAdded==false){ echo "<p>An error occurred, please try again later</p>";} ?>
		</article>
		
	<footer>
		<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
	</footer>
	</body>



</html>