<?php
    session_start();


    $userID = $_SESSION['userId'];
    $chatID = 1; //change to a get request

    

 ?>
