<?php
require("../userDAOClasses/businessTypeClass.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$businessTypeId=$_POST["businessTypeId"];
$userId=$_SESSION["userId"];

$businessTypeDAO=new businessTypeDAO();

$serviceDeleted=$businessTypeDAO->removeBusinessType($businessTypeId,$userId);

if($serviceDeleted==true)
{
	echo "true";
}
else
{
	echo "false";
}

?>