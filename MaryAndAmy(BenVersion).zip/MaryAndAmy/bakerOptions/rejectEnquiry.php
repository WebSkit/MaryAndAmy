<?php
require("../DAO/enquiriesDAO.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$enquiryId=$_POST["enquiryId"];
$enquireBakerId=$_POST["enquireBakerId"];

$enquiriesDAO=new enquiriesDAO();

$enquiryDeleted=$enquiriesDAO->rejectEnquiry($enquiryId,$enquireBakerId);

if($enquiryDeleted==true)
{
	echo "true";
}
else
{
	echo "false";
}



?>