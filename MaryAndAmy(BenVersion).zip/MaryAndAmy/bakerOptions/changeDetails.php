<?php
include("../userDAOClasses/bakerDAO.php");//this require contains a session_start() within it, so it does not need to be used here
//$_SESSION["userId"]=1;
//$_SESSION["accountType"]="baker";//remove both of these tester session variables after you have completed this page
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if($_SESSION["accountType"]!="baker")
{
	die("Only bakers are allowed on this page");
}
else
{
$bakerDAO=new bakerDAO();
$bakerObject=$bakerDAO->getBakerObject($_SESSION["userId"]);
if($bakerObject==false)
{
	die("Something went wrong,Please try again later");
}

if(isset($_POST["editDetails"]))
{
	//echo "posting done";
	$bakerObject->setName($_POST["companyName"]);
	$bakerObject->setAddressLine1($_POST["addressLine1"]);
	$bakerObject->setAddressLine2($_POST["addressLine2"]);
	$bakerObject->setCounty($_POST["county"]);
	$bakerObject->setShopPhoneNumber($_POST["phoneNumber"]);
	$bakerObject->setFacebookPage($_POST["faceBookPage"]);
	$bakerObject->setWebsite($_POST["companyWebSite"]);
	if($bakerDAO->updateDetails($bakerObject)==true)
	{
		echo "update successful";
	}
	else
	{
		echo "update failure";
	}
	//echo $bakerDAO->updateDetails($bakerObject);
}
?>
<!doctype html>
<head>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Change Baker Details</title>
	<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
</head>

<!-- this page will allow the following fields to be editted
	-companyName
	-password
	-addressLine1
	-addressLine2
	-county
	-postCode
	-shopPhoneNumber
	-minNoticeTime
	-facebookPage
	-website
	
	The following will be editted on different pages
	-adminName
	-adminEmail(as the two emails are for two different people)
	-contactName
	-contactEmail
	-servedArea(it goes with some other stuff)
	-buisnessType(because there are multiple)
	-logo(due to it needing an upload)
	
	
	-->
<body>
<header>


      <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>
 
 
        </div>
 
 
        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="../login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="../images/logins.png">
 
          </ul>
        </nav>
      </div>
 
 
 
    </header>
 
    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>



	<form method="post" id="createBakerForm">

		<h3>Company Name</h3>
		<input type="text" name="companyName" value="<?php echo $bakerObject->getName();?>">
		
		<!--<h3>Password</h3>
		<input type="password" name="password" value=""> will remove this as with a encyrpted password, odd results may result by changing it here-->
		
		<h3>address Line 1</h3>
		<input type="text" name="addressLine1" value="<?php echo $bakerObject->getAddressLine1();?>">
		<h3>address Line 2</h3>
		<input type="text" name="addressLine2" value="<?php echo $bakerObject->getAddressLine2();?>">
		<h3>Post Code</h3>
		<input type="text" name="postCode" value="<?php echo $bakerObject->getPostCode();?>">
		<h3>County</h3><!--feel free to remove country if it is irrelevant-->
		<input type="text" name="county" value="<?php echo $bakerObject->getCounty();?>">
		
		<h3>Phone Number</h3>
		<input type="text" name="phoneNumber" value="<?php echo $bakerObject->getShopPhoneNumber();?>">
		
		
		
		<h3>Facebook Page</h3>
		<input type="text" name="faceBookPage"value="<?php echo $bakerObject->getFacebookPage();?>">
		
		<h3>Website Address</h3>
		<input type="text" name="companyWebSite" value="<?php echo $bakerObject->getWebsite();?>"><br>
		<input type="submit" name="editDetails" value="Update Account" ></input>
	</form>
	<footer>
		<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
	</footer>
</body>

</html>

<?php
}//else if you are a logged in baker
?>