<?php
require("../DAO/enquiriesDAO.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$userId=$_SESSION["userId"];

$enquiriesDAO=new enquiriesDAO();
$enquiries=$enquiriesDAO->getEnquiries($userId);

$enquiriesHTML;
if($enquiries!=null)
{
$enquiriesHTML="<table id='enquiriesTable'border='1'>
                        <tr>
                            <th colspan='6'>Enquiries</th>
                        </tr>
                        <tr>
                            <th>Customer ID</th>
                            <th>Enquiry Description</th>
                            <th>Maximum Price</th>
                            <th>Respond By</th>
                            <th colspan='2'>Respond to Enquiry</th>
                        </tr>";

foreach ($enquiries as $enquiry) {
                                array_map('htmlentities', $enquiry);
								$customerId=$enquiry["customerID"];
								$bakerId=$_SESSION["userId"];
							$enquiriesHTML.="<tr>";
							$enquiriesHTML.= "<td data-customerid=".$enquiry['customerID']."'>".$enquiry['customerID']."</td>";
							$enquiriesHTML.= "<td>".$enquiry['enquiryDescription']."</td>";
							$enquiriesHTML.= "<td>".$enquiry['priceRange']."</td>";
							$enquiriesHTML.= "<td>".$enquiry['dueBy']."</td>";
							 if($enquiry["bakerAccept"]==false)
							{
								
                             $enquiriesHTML.="<td><button data-enquirebakerid='". $enquiry["enquireBakerID"] ."' data-enquiryid='".$enquiry["enquiryID"]."' style='width:100%' type='button' class='createConv' name='acceptEnquiry'>Accept</button></td>";
                             $enquiriesHTML.="<td><button data-enquirebakerid='".$enquiry["enquireBakerID"]."' data-enquiryid='". $enquiry["enquiryID"]."' style='width:100%' type='button' name='declineEnquiry' class='rejectEnquiry'>Decline</button></td>";
							  
							}//if the baker has not accepted the query
							else
							{
								
							
							$enquiriesHTML.="<td colspan='2'><button data-enquirebakerid='".$enquiry["enquireBakerID"]."' data-enquiryid='". $enquiry["enquiryID"]."' data-conversationid='" .$enquiry["conversationId"]."' style='width:100%' type='button' class='openChat' name='chatButton'>Chat</button></td>";
							 
							}//if the baker has accepted the enquiry

						$enquiriesHTML.="</tr>";
                         
                             } //end foreach enquiry as enquiries
                         echo $enquiriesHTML;
						
						
						
						
						
						
}//if the enquiry data was found
else
{
	echo "false";
}//if the enquiries data was not found



?>