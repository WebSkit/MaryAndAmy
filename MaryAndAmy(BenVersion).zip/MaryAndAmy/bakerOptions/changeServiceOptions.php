<?php
require("../userDAOClasses/bakerDAO.php");//session started in this method already
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$bakerDAO=new bakerDAO();
if(isset($_POST["submit"]))
{
	$dataUpdated=$bakerDAO->changeServiceOptions($_POST["serviceArea"],$_POST["minNoticeTime"],$_SESSION["userId"]);
	
}
$bakerObject=$bakerDAO->getBakerObject($_SESSION["userId"]);


?>
<!DOCTYPE HTML>
<head>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Change Baker Details</title>
	<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
</head>
<body>
<header>


      <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>
 
 
        </div>
 
 
        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="../login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="../images/logins.png">
 
          </ul>
        </nav>
      </div>
 
 
 
    </header>
 
    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>
<form action="changeServiceOptions.php" method="post">
			<br>
			<input type="text" name="serviceArea" id="serviceArea" value="<?php echo $bakerObject->getServedArea();?>">Service Area<br>
			<input type="text" name="minNoticeTime" id="minNoticeTime" value="<?php echo $bakerObject->getMinNoticeTime();?>">Minimum Notice Time<br>
			<input type="submit" value="Change Services" name="submit">
			<?php if(isset($dataUpdated)){ if($dataUpdated==true){ echo "<p>Your Information has been updated</p>";}else{ echo "<p>Something went Wrong, please ensure that both values are numbers</p>";} }?>
</form>
	<footer>
		<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
	</footer>
</body>
</html>