<?php
$server="localhost";
$usernameS="MaryAndAmy";
$passwordS="ENQ5KFT51BOU2Dhq";
$database="maryandamy";
?>
