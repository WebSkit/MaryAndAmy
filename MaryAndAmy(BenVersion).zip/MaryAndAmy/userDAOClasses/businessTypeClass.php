<?php
$requiredAddress='../databaseDetails.php';
require($requiredAddress);

class businessTypeDAO
	{
		var $serverName;
		var $username;
		var $password;
		var $database;
		function __construct()
		{
			$this->serverName=$GLOBALS["server"];
			$this->username=$GLOBALS["usernameS"];
			$this->password=$GLOBALS["passwordS"];
			$this->database=$GLOBALS["database"];
		}//end constructor

		function getConnection()
		{
			$connection = new mysqli($this->serverName, $this->username, $this->password, $this->database);
			if($connection->connect_error)
			{
				die("Failed to establish a connection, please try again later");
			}//if there was a connection error
			return $connection;
		}//end getConnection
		
		function getAllBusinessTypes()
		{
			$connection=$this->getConnection();
			$query="SELECT * FROM businessType WHERE businessTypeID<> ALL (SELECT businessTypeID FROM bakerBusinessType WHERE bakerID=".$_SESSION["userId"].") ";
			//query=get all data the services from the table that are not currently active to the logged in baker
			if($result=$connection->query($query))
			{
				$businessTypeData=array();
				$count=0;
				while($row=$result->fetch_assoc())
				{
					$businessTypeData[$count]=array("businessTypeId"=>$row["businessTypeID"], "businessType"=>$row["businessType"]);
					$count++;
				}
				return $businessTypeData;
			}//if the query was successful
			else
			{
				return false;
			}//if the query failed
		}//end getAllBusinessTypes
		
		function getAllActiveBusinessTypes($bakerId)
		{
			$connection=$this->getConnection();
			$query="SELECT * FROM bakerBusinessType AS b JOIN businessType AS t WHERE bakerId=? AND b.businessTypeID=t.businessTypeID";
			$prepStatment=$connection->prepare($query);
			$prepStatment->bind_param("s",$bakerId);
			echo $connection->error;
			if($prepStatment->execute())
			{
				echo $connection->error;
				$result = $prepStatment->get_result();

				$bakerBusinessType=array();
				$count=0;
				while($row=$result->fetch_assoc())
				{
					$bakerBusinessType[$count]=array("businessType"=>$row["businessType"], "businessTypeId"=>$row["businessTypeID"]);
					$count++;
				}
				return $bakerBusinessType;
			}//if query executed successfully
			else
			{
				echo $connection->error;

				return false;
			}//if the query failed
			
			return false;
		}
		function addBusinessType($businessTypeId,$bakerId)
		{
			
			$connection=$this->getConnection();
			$checkQuery="SELECT * FROM bakerBusinessType WHERE bakerID=? AND businessTypeID=?";//check if the value has already been added
			$checkPrepStatement=$connection->prepare($checkQuery);
			$checkPrepStatement->bind_param("ss",$bakerId,$businessTypeId);
			if($checkPrepStatement->execute())
			{
				$result=$checkPrepStatement->get_result();
				while($row=$result->fetch_assoc())
				{
					if($row["businessTypeID"]==$businessTypeId)
					{
						return false;
					}
				}//check every of this bakers active services, if they already have it active, then stop the function
			}//if query executed
			else
			{
				return false;
			}//if the query failed to execute
			
			//if the code gets here, by implication, the businessType they have entered, is already in use for them
			
			$query="INSERT INTO bakerBusinessType(businessTypeID,bakerID) VALUES(?,?)";
			$prepStatment=$connection->prepare($query);
			$prepStatment->bind_param("ss",$businessTypeId,$bakerId);
			if($prepStatment->execute())
			{

				return true;
			}//if the data was inserted successfully
			else
			{
				return false;
			}//if the query failed
		}//end addBusinessType
		
		function removeBusinessType($businessTypeId,$userId)
		{
			$connection=$this->getConnection();
			$query="DELETE FROM bakerbusinesstype WHERE businessTypeID=? AND bakerID=?";
			$prepStatment=$connection->prepare($query);
			$prepStatment->bind_param("ss",$businessTypeId,$userId);
			if($prepStatment->execute())
			{
				return true;
			}//if the value was deleted
			else
			{
				
				return false;
			}
		}//end removeBusinessType
	}//end businessTypeDAO



?>