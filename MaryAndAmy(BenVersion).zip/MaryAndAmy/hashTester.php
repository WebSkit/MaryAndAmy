<?php
require("DAO/hashClassDAO.php");

$hashDAO=new CredentialHashDAO();

$array=$hashDAO->hashPassword("helloWorld");

echo $array[0]."<br>";//hashed pass
echo $array[1];//salt
$userId=4;
$hashDAO->insertPasswordDB("customer",$array,$userId);
$hashDAO->insertSaltDB("customer",$array,$userId)
?>