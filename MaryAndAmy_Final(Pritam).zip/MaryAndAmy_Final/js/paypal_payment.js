var CREATE_PAYMENT_URL  = '/../payment/createPayment.php';
var EXECUTE_PAYMENT_URL = '/../payment/executePayment.php?success=true';

paypal.Button.render({

    env: 'sandbox',

    commit: true, // Show a 'Pay Now' button

    payment: function() {
        return paypal.request.post(CREATE_PAYMENT_URL).then(function(data) {
            console.log(data);
            return data.id;
        });
    },

    onAuthorize: function(data) {
        return paypal.request.post(data.returnUrl, {
            paymentID: data.paymentID,
            payerID:   data.payerID
        }).then(function(res) {
            console.log(res);
            // The payment is complete!
            // You can now show a confirmation message to the customer
            alert("Payment Successful");
        });
    },
    onCancel: function(data, actions) {
        alert("Cancelled");
    },

      onError: function(err) {
        alert("Error");
      }

}, '#paypal-button-container');
