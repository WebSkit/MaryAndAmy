<?php
require("chat.php");//one of these starts the session
require("../DAO/enquiriesDAO.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$customerId=$_POST["customerId"];
$enquireBakerID=$_POST["enquireBakerId"];
$bakerId=$_SESSION["userId"];



$chatDAO=new chatDAO();
$conversationId=$chatDAO->createConversation($bakerId,$customerId);

if($conversationId!=false)
{
	$enquiriesDAO=new enquiriesDAO();
	$conversationAdded=$enquiriesDAO->linkConversation($conversationId,$enquireBakerID);
	
	
	if($conversationAdded!=false)
	{
		echo $conversationId;//if the linking was successful,return the conversationId 
	}
	else
	{
		echo "false(had an id, just no linking of conversation)";
	}
}
else
{
	echo "false(conversation was not created)";
}
?>