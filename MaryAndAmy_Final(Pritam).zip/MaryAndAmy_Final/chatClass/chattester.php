<?php

require("chat.php");

$chatDAO=new chatDAO();

$value=$chatDAO->createConversation(1,1);
echo $value;


?>