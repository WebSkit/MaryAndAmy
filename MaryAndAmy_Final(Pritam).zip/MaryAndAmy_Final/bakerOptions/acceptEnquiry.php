<?php
require("../DAO/enquiriesDAO.php");//session started here
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$enquireBakerId=$_POST["enquireBakerId"];
$enquiriesDAO=new enquiriesDAO();
$customerId=$enquiriesDAO->acceptEnquiry($enquireBakerId);

if($customerId==false)
{
	echo "false";
}//if the query went wrong
else
{
	echo $customerId;
}//if the query was successful


?>