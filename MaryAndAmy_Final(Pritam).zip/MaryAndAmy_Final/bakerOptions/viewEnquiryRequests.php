<?php
    require(realpath(dirname(__FILE__).'/../DAO/enquiriesDAO.php'));//session started here
	if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
	//$_SESSION["userId"]=1;
	//$_SESSION["accountType"]="baker";
    $userID = $_SESSION['userId'];

    if($_SESSION["accountType"]!="baker")
    {
    	die("You must be logged in as a baker to access this page");
    }//if not a baker, kill the page
    else//else allow the rest of the page to be loaded
    {
        $enquiriesDAO = new enquiriesDAO();
        $enquiries = $enquiriesDAO -> getEnquiries($userID);
        if( $enquiries!="" && count($enquiries) > 0) {//if no enquiries exist, then the array is not populated and is considered a blank value(it won't be recognised as an array)
            echo count($enquiries);
?>
            <!DOCTYPE HTML>
            <head>
				<meta name="keywords" content="" />
				<meta name="description" content="" />
				<meta http-equiv="content-type" content="text/html; charset=utf-8" />
				<title>View Enquiries</title>
				<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
				<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
		</head>
            <body>
				<script type="text/javascript" src="../chatClass/chatManager.js"></script>

               <header>


      <div class="container">
        <div id="branding">


 <h1>  Mary <span class="highlight"> & </span> Amy </h1>


        </div>


        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>

<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="contact.html"><h2>Login/Register<h2></a></li>  <?php } ?>

<img src="../images/logins.png">

          </ul>
        </nav>
      </div>



    </header>

    <section id="showcase">
      <div class="container">

        <h1></h1>
        <p></p>
      </div>
    </section>
                <section id="enquiriesList">
                    <table id="enquiriesTable"border="1">
                        <tr>
                            <th colspan="7">Enquiries</th>
                        </tr>
                        <tr>
                            <th>Customer ID</th>
                            <th>Enquiry Description</th>
                            <th>Maximum Price</th>
                            <th>Respond By</th>
                            <th colspan="2">Respond to Enquiry</th>
                        </tr>
                        <?php foreach ($enquiries as $enquiry) {
                                array_map('htmlentities', $enquiry);
								$customerId=$enquiry["customerID"];
								$bakerId=$_SESSION["userId"];
                         ?>
                         <tr>
                             <!--<td><?php //echo implode('</td><td>', $enquiry); ?></td>-->
							<?php echo "<td data-customerid=".$enquiry["customerID"].">".$enquiry["customerID"]."</td>";?>
							<?php echo "<td>".$enquiry["enquiryDescription"]."</td>";?>
							<?php echo "<td>".$enquiry["priceRange"]."</td>";?>
							<?php echo "<td>".$enquiry["dueBy"]."</td>";?>
							<?php if($enquiry["bakerAccept"]==false)
							{
								?>
                             <td><button data-enquirebakerid="<?php echo $enquiry["enquireBakerID"]; ?>" data-enquiryid="<?php echo $enquiry["enquiryID"]; ?>" style="width:100%"type="button" class="createConv" name="acceptEnquiry">Accept</button></td>
                             <td><button data-enquirebakerid="<?php echo $enquiry["enquireBakerID"]; ?>" data-enquiryid="<?php echo $enquiry["enquiryID"];?> style="width:100%"type="button" name="declineEnquiry" class="rejectEnquiry">Decline</button></td>
							<?php
							}//if the baker has not accepted the query
							else
							{

							?>
							<td><button data-enquirebakerid="<?php echo $enquiry["enquireBakerID"]; ?>" data-enquiryid="<?php echo $enquiry["enquiryID"]; ?>" data-conversationid="<?php echo $enquiry["conversationId"]; ?>" style="width:100%"type="button" class="openChat" name="chatButton">Chat</button></td>
                            <td><a href="addJob.php?customerID=<?php echo $enquiry["customerID"];?>&enquiryID=<?php echo $enquiry["enquiryID"];?>"><button style="width:100%"type="button" class="createJob" name="createJobButton">Create Job</button></a></td>
							<?php
							}//if the baker has accepted the enquiry?>

						</tr>
                         <?php
                             } //end foreach
                         ?>
                    </table>
                </section> <!--end enquiriesList section-->
				<section id="chatCollection">

				</section><!--end chatCollection-->
				<footer>
					<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
				</footer>
            </body>
            </html>

<?php
        } //end if (there are enquiries in the array) statement
        else {
            echo "There are no enquiries for you to respond to.";
        }
    } //end else (if baker) statement
?>
