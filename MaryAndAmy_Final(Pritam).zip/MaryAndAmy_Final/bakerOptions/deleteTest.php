<?php
$_SESSION["userId"]=2;
$target_dir = "../logos/"."BakerId".$_SESSION["userId"];
$files = scandir ($target_dir); // get all file names
$arraySize=sizeof($files);
for($i=0;$i<$arraySize;$i++){ // iterate through files in folder
 
 
 if($files[$i]=="." || $files[$i]=="..")
 {
 }//if the system finds the two dot values that linux systems add to the list
 else
 {
	 if(unlink($target_dir."/".$files[$i])) // delete file
	{
		echo "success";
	}
	else
	{
		echo "failure";
	}
 }//else
   
  
}//for each item in array
	?>