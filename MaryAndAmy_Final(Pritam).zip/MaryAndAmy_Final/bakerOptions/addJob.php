<?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    require __DIR__  . '/../DAO/productDAO.php';
    require __DIR__  . '/../DAO/jobDAO.php';


    $accountType = $_SESSION['accountType'];

    if($accountType != "baker") {
        die("You are not authorised to view this page");
    }
    $bakerID = $_SESSION['userId'];

    $jobDAO = new jobDAO();
    $productDAO = new productDAO();
    $products = $productDAO -> getProduct($bakerID);

    if(isset($_POST["jobSubmit"])) {
        $customerID = $_POST["customerID"];
        $enquiryID = $_POST["enquiryID"];
        $productID = $_POST["products"];
        $jobDescription = $_POST["jobDescription"];
        $price = $_POST["price"];

        if (is_numeric($productID)) {
            $jobDAO -> createJob($bakerID,$customerID,$enquiryID,$jobDescription,$price,$productID);
        }
        else {
            $jobDAO -> createJob($bakerID,$customerID,$enquiryID,$jobDescription,$price,"n/a");
        }
    }
 ?>

 <body>
 	<!--htmlspecialchars() converts special characters like '<' and '>' to HTML entities.(in this case &lt; and &gt;).
 		This prevents attackers from exploiting the code by injecting HTML or Javascript code (Cross-site Scripting attacks) in the form.
 		$_SERVER["PHP_SELF"] allows error messages generated when submitting the form, such as not filling in a required field, to be displayed
 		on the same page.
 	-->
 	<form method="post" id="addJobForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <h2>Create a Job</h2>
        <input type="hidden" name="enquiryID" value="<?php echo $_GET["enquiryID"];?>">
        <input type="hidden" name="customerID" value="<?php echo $_GET["customerID"];?>">
 		<h3>Product</h3>
 		<!--value attribute will allow the values entered by user to remain in the fields in the event that the form has been submitted
 			but validation has failed-->
 		<select name="products">
            <option selected value> -- select an option -- </option>
            <?php
                foreach ($products as $product) {
                    array_map('htmlentities', $product);
                    $productID =$product["productID"];
                    $productDescription = $product["productDescription"];
                    $price = $product["price"];
            ?>
                <option value="<?php echo $productID;?>"><?php echo $productID." - ".$productDescription;?></option>
                <?php
                } //end foreach
                ?>
        </select>
        <h3>Job Description *</h3>
        <textarea name="jobDescription" placeholder="Enter a description for the job" rows="4" cols="50" required></textarea>
        <h3>Price *</h3>
        <input type="text" name="price" required></input>
        <!-- <h3>Delivery Date *</h3>
        <input type="date" name ="deliveryDate" required></input> -->
        <br><br>
 		<input type="submit" value="Create Job" name="jobSubmit">

 	</form><!--end new_customer_form-->
 </body>
