<?php
 ?>
 <!DOCTYPE html>

 <head>
     <meta http-equiv="X-UA-Compatible" content="IE=edge" />
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <script src="https://www.paypalobjects.com/api/checkout.js"></script>
 </head>

 <body>
     <div id="paypal-button-container"></div>

     <script src="../js/paypal_payment.js"></script>
 </body>
