<?php
	require("../DAO/enquiriesDAO.php");
	require("../classes/enquiry.php");
	//$_SESSION["userId"]=1;
	//$_SESSION["accountType"]="customer";
	if(isset($_POST["enquirySubmit"]))
	{	
		//echo $_POST["DBD"];
		//still making the date datatype respondable
		$tempEnquiry= new enquiry ($_SESSION["userId"],$_POST["eD"],$_POST["priceRange"],$_POST["DBD"]);
		$tempDAO=new enquiriesDAO();
		$enquiryCreated=$tempDAO->createEnquiry($tempEnquiry);
		if($enquiryCreated==true)
		{
			echo "Enquiry Made";
		}
		else
		{
			echo "something went wrong, please try again later";
		}
	}//if data was submitted successfully from the form
?>
<!DOCTYPE HTML>
<head>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Change Baker Details</title>
	<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
</head>
<body>
 <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>


        </div>


        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="../login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="../images/logins.png">

          </ul>
        </nav>
      </div>



    </header>

    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>

	<h2>Create an Enquiry</h2>
	<form method="post" id="createEnquiryForm">
		<h3>Enquiry Description</h3>
		<input type="text" name="eD">
		
		<h3>Price Range</h3>
		<input type="text" name="priceRange">
		
		<h3>Due By Date (YYYY-MM-DD)</h3>
		<input type="text" name="DBD">
		
		<input type="submit" value="Create An Enquiry" name="enquirySubmit">
	</form><!--end createEnquiryForm-->
	<footer>
		<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
	</footer>
</body>
</html>
