<?php
	require("../userDAOClasses/customerDAO.php");
	if(isset($_POST["customerSubmit"]))
	{
		$tempCustomer=new Customer($_POST["firstName"],$_POST["password"],$_POST["surname"],$_POST["email"],$_POST["addressLine1"],$_POST["addressLine2"],$_POST["county"],$_POST["postcode"]);
		//var_dump($temp_user);
		$tempDao=new customerDAO();
		$accountCreated=$tempDao->updateCustomer($tempCustomer);
		if($accountCreated==true)
		{
			echo "account updated";
		}
		else
		{
			echo "something went wrong, please try again later";
		}
	}//if data was submitted successfully from the form
?>
<!DOCTYPE HTML>
<head>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Change Baker Details</title>
	<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
</head>
<body>
 <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>


        </div>


        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="../login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="../images/logins.png">

          </ul>
        </nav>
      </div>



    </header>

    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>

	<form method="post" id="updateCustomerForm">
		<h3>First Name</h3>
		<input type="text" name="firstName">
		<h3>Surname</h3>
		<input type="text" name="surname">
		<h3>Password</h3>
		<input type="password" name="password">
		<h3>Email</h3>
		<input type="text" name="email">
		<h3>address Line 1</h3>
		<input type="text" name="addressLine1">
		<h3>address Line 2</h3>
		<input type="text" name="addressLine2">
		<h3>County</h3>
		<input type="text" name="county">
		<h3>Post Code</h3>
		<input type="text" name="postcode">

		<input type="submit" value="Create Account" name="customerSubmit">

	</form><!--end update_customer_form-->
	<footer>
		<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
	</footer>
</body>
</html>
