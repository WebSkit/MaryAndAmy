<?php
	require("../DAO/enquiryDAO.php");
	require("../DAO/enquireBakerDAO.php");
	$_SESSION["userId"]=1;
	$_SESSION["accountType"]="customer";
	//deleteable
	
	
	if(isset($_POST["enquirySubmit"]))
	{	
		//creating the enquiry
		$tempEnquiry= new enquiry ($_SESSION["userId"],$_POST["eD"],$_POST["priceRange"],$_POST["DBD"]);
		$tempDAO=new enquiryDAO();
		$enquiryCreated=$tempDAO->createEnquiry($tempEnquiry);
		if($enquiryCreated==true)
		{
			echo "enquiry created";
		}
		else
		{
			echo "something went wrong, please try again later";
		}
		//finding the enquiry
		$enquiryID = $tempDAO->findEnquiry($_SESSION["userId"]);//used in enquireBaker
		if ($enquiryID->num_rows > 0) {
			// output data of each row
			while($row = $enquiryID->fetch_assoc()) {
				//echo "id: " . $row['MAX(enquiryID)'] . "<br>";
				$v=$row['MAX(enquiryID)'];
			}
		}
		else
		{
			echo "num row prob";
		}
		
		//creating the enquireBaker
		$tempDAO=new enquireBakerDAO();
		$tempEnquireBaker= new enquireBaker ($_POST["bakerId"],$v,true,false);//first true is customer accept, false is for the baker accept
		$enquireBakerCreated=$tempDAO->createEnquireBaker($tempEnquireBaker);
		if($enquireBakerCreated==true)
		{
			//echo "enquireBaker created";
		}
		else
		{
			echo "something went wrong with enquireBaker, please try again later";
		}
				
	}//if data was submitted successfully from the form
?>


<body>
	<h2>Create an Enquiry</h2>
	<form method="post" id="createEnquiryForm">
		<h3>Enquiry Description</h3>
		<input type="text" name="eD">
		
		<h3>Price Range</h3>
		<input type="text" name="priceRange">
		
		<h3>Due By Date (YYYY-MM-DD)</h3>
		<input type="text" name="DBD">
		
		<input type="hidden" value="<?php echo $_GET["bakerId"];?>" name="bakerId"></input>
		<input type="submit" value="Create An Enquiry" name="enquirySubmit">
	</form><!--end createEnquiryForm-->
</body>