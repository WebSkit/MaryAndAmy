

CREATE TABLE gallery_category ( 
  category_id bigint(20) unsigned NOT NULL auto_increment, 
  category_name varchar(50) NOT NULL default '0', 
  PRIMARY KEY  (category_id), 
  KEY category_id (category_id) 
) TYPE=MyISAM; 
 
CREATE TABLE gallery_photos ( 
  photo_id bigint(20) unsigned NOT NULL auto_increment, 
  photo_filename varchar(25), 
  photo_caption text, 
  photo_category bigint(20) unsigned NOT NULL default '0', 
  PRIMARY KEY  (photo_id), 
  KEY photo_id (photo_id) 
) TYPE=MyISAM;


INSERT INTO gallery_category(`category_name`) VALUES('My First Gallery')

<?php  
  include 'config.inc.php';  
  
   
  $photo_upload_fields = '';  
  $counter = 1;  
  
  // If we want more fields, then use, preupload.php?number_of_fields=20  
  $number_of_fields = (isset($_GET['number_of_fields'])) ?  
    (int)($_GET['number_of_fields']) : 5;  
    
  $result = mysql_query('SELECT category_id,category_name FROM gallery_category');  
  while($row = mysql_fetch_array($result)) {  
    $photo_category_list .= <<<__HTML_END  
<option value="$row[0]">$row[1]</option>n  
__HTML_END;  
  }  
  mysql_free_result( $result );    
  
 
  while($counter <= $number_of_fields) {  
    $photo_upload_fields .= <<<__HTML_END  
<tr><td>  
  Photo {$counter}:  
  <input name="photo_filename[]"  
type="file" />  
</td></tr>  
<tr><td>  
  Caption:  
  <textarea name="photo_caption[]" cols="30"  
    rows="1"></textarea>  
</td></tr>  
__HTML_END;  
    $counter++;  
  }  
  
  // Final Output  
  echo <<<__HTML_END  
<html>  
<head>  
<title>Lets upload Photos</title>  
</head>  
<body>  
<form enctype="multipart/form-data"  
  action="upload.php" method="post"  
  name="upload_form">  
  <table width="90%" border="0"  
    align="center" style="width: 90%;">  
    <tr><td>  
      Select Category  
      <select name="category">  
      $photo_category_list  
      </select>  
    </td></tr>  
    <! - Insert the image fields here -->  
    $photo_upload_fields  
    <tr><td>  
      <input type="submit" name="submit"  
        value="Add Photos" />  
    </td></tr>  
  </table>  
</form>  
</body>  
</html>  
__HTML_END;  
?>

// Fetching the image array sent by preupload.php  
  
$photos_uploaded = $_FILES['photo_filename'];  
  
// Fetch the image caption array  
  
$photo_captions = $_POST['photo_captions'];


$photo_types = array(       
  'image/jpeg' => 'jpg',   
  'image/gif' => 'gif',      
  'image/x-png' => 'png'   
);


while($counter <= count($photos_uploaded)) {   
  if($photos_uploaded['size'][$counter] > 0) {   
    if(!array_key_exists($photos_uploaded['type'][$counter], $photo_types)) {   
      $result_final .= 'File ' . ($counter + 1) .   
        ' is not a photo<br />';   
    } else {   
      // Great the file is an image, we will add this file   
    }   
  }   
}


mysql_query("   
  INSERT INTO gallery_photos (   
    photo_filename,   
    photo_caption,   
    photo_category   
  ) VALUES (   
    '0',   
    '" . $photo_captions[$counter]) . "',   
    '" . $_POST['category'] . "'   
  )   
");   
   
$new_id = mysql_insert_id(); // New Id generated