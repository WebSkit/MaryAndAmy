<?php
$requiredAddress="DAO/reviewsDAO.php";
require($requiredAddress);
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if($_SESSION["accountType"]!="baker")
{
	die("You must be logged in as a baker to access this page");
}//if not a baker, kill the page
else//else allow the rest of the page to be loaded
{
?>

<!--
list of business types below
1, Birthday cake
  2, Christening / New baby cake
  3, Anniversary cake
  4, Wedding cake
  5, Other celebration cakes
- Cupcakes, Muffins
- Muffin-cakes
- Candy
- Miscellaneous
-->
<!doctype html>
<head>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Bakers Profile Page</title>
	<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="css/style copy 3.css" />
		
</head>

	<body>
		<header>


      <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>


        </div>


        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="images/logins.png">

          </ul>
        </nav>
      </div>



    </header>

    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>
			<section id="bakerOptions">
			<article id="editDetails">
			<!-- <img src = "img/striped.jpg" > -->
				<a href="bakerOptions/changeDetails.php"><button type="button" name="editAccountDetails" value="Edit Account Details">Edit Account</button></a>
				<a href="bakerOptions/changeServiceOptions.php"><button type="button"  name="serviceOptions" value="Change Serving Area or Delivery options">Change Service Options</button></a>
				<a href="bakerOptions/changePassword.php"><button type="button" name="editPassword" value "Change Password">Change Password</button></a>
				<a href="bakerOptions/uploadLogo.php"><button type="button" name="uploadImages">Upload Logo</button></a>
			</article><!--end editDetails-->
			<article id="orderControl">
				<a href="bakerOptions/addProduct.php"><button type="button" name="addProduct">Create New Product</button></a>
				<a href="bakerOptions/reviewOrders.php"><button type="button" name="viewOrders" value="View Orders">View Orders</button></a>
				<a href="bakerOptions/viewEnquiryRequests.php"><button type="button" name="viewEnquiries" value="Enquiry Requests">View Enquiries</button></a>
			</article>
			<article id="reviews">
			<div id = "reviews">
				<?php
					$reviewDAO=new reviewsDAO();
					$reviewsArray=$reviewDAO->getReviews($_SESSION["userId"]);
					if($reviewsArray==null)
					{
						echo "<p>No reviews have been made about any of your products</p>";
					}
					else
					{

						?>
						<ul id="reviewList">
							<?php
								$reviewCount=sizeof($reviewsArray);
								$tempCount=0;
								while($tempCount<$reviewCount)
								{
									?>
										<li>
											<ul id="review "<?php echo $tempCount+1;?>>
												<li>Product:<?php echo $reviewsArray[$tempCount]["productDescription"];?></li>
												<li>Rating: <?php echo $reviewsArray[$tempCount]["rating"];?></li>
												<li>Review: <?php echo $reviewsArray[$tempCount]["review"];?></li>
												<li>By<?php echo " ".$reviewsArray[$tempCount]["customerName"];?></li>
												<li><button class="<?php if($reviewsArray[$tempCount]["flagged"]==false){ echo "flagReview";}else{ echo "flagPending";}?>" type="button" data-reviewid="<?php echo $reviewsArray[$tempCount]["reviewId"]; ?>"><?php if($reviewsArray[$tempCount]["flagged"]==false){echo "Flag Review";}else{echo "Flag waiting Approval";}?></button></li>
											</ul>
										</li>
									<?php
									$tempCount++;
								}//while there are reviews in the list

							?>
						</ul>
						<?php

					}//else if there are reviews about the baker

				?>
			</div>
			</article>
			<article id="adminShop">
			<a href="bakerOptions/buyImageSpace.php"><button type="button" name="buyImageSpace">Buy Image Space</button></a>
			</article>
		</section>
			</div>
			
		</div>
<footer>
	<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
</footer>
	</body>



</html>
<?php
}//else if the user is a baker

?>
