<?php

require __DIR__  . '/../vendor/autoload.php';
require __DIR__  . '/../paypalKeys.php';
require __DIR__  . '/../DAO/paymentDAO.php';

$paymentDAO = new paymentDAO();
$jobID = 2;

$apiContext = new \PayPal\Rest\ApiContext(
    new \PayPal\Auth\OAuthTokenCredential(
        $GLOBALS["CLIENT_ID"],
        $GLOBALS["CLIENT_SECRET"]
    )
);
// ### Approval Status
// Determine if the user approved the payment or not
if (isset($_GET['success']) && $_GET['success'] == 'true') {
    $paymentId = $_POST['paymentID'];
    $payment = \PayPal\Api\Payment::get($paymentId, $apiContext);

    $execution = new \PayPal\Api\PaymentExecution();
    $execution->setPayerId($_POST['payerID']);

    try {
        // Execute the payment

        $result = $payment->execute($execution, $apiContext);
        try {
            $payment = \PayPal\Api\Payment::get($paymentId, $apiContext);
            $paymentDAO->updatePayment($jobID);
        } catch (Exception $ex) {
            echo $ex;
        }
    } catch (Exception $ex) {
        echo $ex;
    }
    echo $payment;
    return $payment;
} else {
    echo $_GET['success'];
}
