<?php
$requiredAddress=realpath(dirname(__FILE__).'\..\databaseDetails.php');
require($requiredAddress);
class jobDAO{
    function __construct()
    {
    }//constructor
    function getConnection()
    {
        $connection=new mysqli($GLOBALS["server"],$GLOBALS["usernameS"],$GLOBALS["passwordS"],$GLOBALS["database"]);
        if($connection->connect_error)
        {
            die("Failed to establish a connection, please try again later");
        }//if there was a connection error
        return $connection;
    }//end getConnection

    function createJob($bakerID,$customerID,$enquiryID,$jobDescription,$price,$productID)
    {
        $connection = $this->getConnection();
        $query;
        $prepStatement;
        if(!is_numeric($productID)) {
            $query = "INSERT INTO job (bakerID, customerID, enquiryID, jobDescription, price, isComplete, customerAcceptJob)
                                VALUES (?,?,?,?,?,0,0)";
            $prepStatement=$connection->prepare($query);
            $prepStatement->bind_param("sssss",$bakerID,$customerID,$enquiryID,$jobDescription,$price);
        }
        else {
            $query = "INSERT INTO job (bakerID, customerID, enquiryID, jobDescription, productID, price, isComplete, customerAcceptJob)
            VALUES (?,?,?,?,?,?,0,0)";
            $prepStatement=$connection->prepare($query);
            $prepStatement->bind_param("ssssss",$bakerID,$customerID,$enquiryID,$jobDescription,$productID,$price);
        }

        if($prepStatement->execute())
        {
            return true;
        }//if query was a success
        else
        {
            die("something went wrong".$connection->error);
            return false;
        }//if query was a failure

    }
}
 ?>
