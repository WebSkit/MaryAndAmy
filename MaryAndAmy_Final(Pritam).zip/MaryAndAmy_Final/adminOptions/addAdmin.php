<?php
	require("../userDAOClasses/adminDAO.php");
	if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
	if(isset($_POST["updateDetails"])){
		$tempAdmin = new Admin($_POST["N_username"],$_POST["N_password"],$_POST["N_email"],$_POST["N_phone"]);
		$tempAdminDAO = new adminDAO();
		$updateAdmin = $tempAdminDAO->createAdmin($tempAdmin);
		if($updateAdmin==true)
		{
			echo "Details has been updated successfully";
		}
		else
		{
			echo "something happened try again";
		}
	}
?>
<!DOCTYPE HTML>
<head>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Add An Admin Account</title>
	<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="../css/style copy 3.css" />
</head>
<body>
<header>


      <div class="container">
        <div id="branding">
	
         
 <h1>  Mary <span class="highlight"> & </span> Amy </h1>


        </div>


        <nav>
          <ul>
            <li class="current"><a href="homeaPage.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
<?php if(isset($_SESSION["userId"]) && $_SESSION["userId"]!=null){ ?><li><a href="../logout.php"><h2>Logout</h2></a></li><?php } else{ ?> <li><a href="../login2.php"><h2>Login/Register<h2></a></li>  <?php } ?>
<img src="../images/logins.png">

          </ul>
        </nav>
      </div>



    </header>

    <section id="showcase">
      <div class="container">
     
        <h1></h1>
        <p></p>
      </div>
    </section>
	<form method="post" id="addAdmin">

		<h1>Add Administration</h1>


		<h3>Username</h3>
		<input type="text" name="N_username">
		<br>
		<h3>Password</h3>
		<input type="password" name="N_password">
		<br>
		<h3>E-mail<h3>
		<input type="text" name="N_email">
		<br>
		<h3>Contact number<h3>
		<input type="text" name ="N_phone">
		<br><br>
		<input type="submit" name="updateDetails">


	</form>
<footer>
		<p style="color:white;">Mary And Amy, Copyright &copy; 2017</p>
	</footer>
</body>
</html>
