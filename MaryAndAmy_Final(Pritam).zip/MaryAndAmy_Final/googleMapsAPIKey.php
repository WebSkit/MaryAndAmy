<?php
	$MAPS_API_KEY="AIzaSyCcMv6vKb69ZxDbGFe0skOfPpQ0adhR4s8";

?>
