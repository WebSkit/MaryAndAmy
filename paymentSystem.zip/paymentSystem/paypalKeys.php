<?php
    $CLIENT_ID = 'AX1N5ubnl5qXZBnha_j0dL5r_3HZztfQA6wo_Joy57pDzRDTzPaZQfapuqA0Yo7SCAYmi3R3K6cNsSnm';
    $CLIENT_SECRET = 'EJIwr_sCFdRgahA9l-nKjT3gsX0BqSmS2JtaKwcNb8UKhl0G5AhPV_rOtLSmfNtUIYeNIC4qLt4lEdhJ';
 ?>
