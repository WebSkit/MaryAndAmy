<?php
    require __DIR__  . '/../vendor/autoload.php';
    require __DIR__  . '/../paypalKeys.php';
    require __DIR__  . '/../DAO/paymentDAO.php';

    $paymentDAO = new paymentDAO();
    $jobID = 2;

    $apiContext = new \PayPal\Rest\ApiContext(
        new \PayPal\Auth\OAuthTokenCredential(
            $GLOBALS["CLIENT_ID"],
            $GLOBALS["CLIENT_SECRET"]
        )
    );

    $payer = new \PayPal\Api\Payer();
    $payer->setPaymentMethod('paypal');

    $amount = new \PayPal\Api\Amount();
    $amount->setTotal('10.00');
    $amount->setCurrency('GBP');

    $transaction = new \PayPal\Api\Transaction();
    $transaction->setAmount($amount);

    $redirectUrls = new \PayPal\Api\RedirectUrls();
    $redirectUrls->setReturnUrl("http://localhost/MaryAndAmy/payment/executePayment.php?success=true")
        ->setCancelUrl("http://localhost/MaryAndAmy/payment/executePayment.php?success=false");

    $payment = new \PayPal\Api\Payment();
    $payment->setIntent('sale')
        ->setPayer($payer)
        ->setTransactions(array($transaction))
        ->setRedirectUrls($redirectUrls);

        // After Step 3
    try {
        $payment->create($apiContext);
        echo $payment;
        $paymentDAO->createPayment($jobID);

        //echo "\n\nRedirect user to approval_url: " . $payment->getApprovalLink() . "\n";
    }
    catch (\PayPal\Exception\PayPalConnectionException $ex) {
        // This will print the detailed information on the exception.
        //REALLY HELPFUL FOR DEBUGGING
        echo $ex->getData();
    }
 ?>
